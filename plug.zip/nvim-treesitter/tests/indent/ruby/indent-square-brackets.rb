def indent_square_brackets
  [
    []
  ]
end
