<?php

class example
{
    public int $variable;
    // indentation works correctly here

    public function foo()
    {
        // indentation works correctly here
    }
}
